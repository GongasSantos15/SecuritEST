const { CosmosClient } = require("@azure/cosmos");

const client = new CosmosClient({
  endpoint: process.env.COSMOS_ENDPOINT,
  key: process.env.COSMOS_KEY
});

const database = client.database(process.env.COSMOS_DATABASE);
const container = database.container(process.env.COSMOS_CONTAINER);

module.exports = async function (context, req) {
  // ─── CORS ────────────────────────────────────────────────────────────────
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };

  if (req.method === "OPTIONS") {
    context.res = { status: 204, headers };
    return;
  }

  // ─── GET /api/function → listar scans do CosmosDB ────────────────────────
  if (req.method === "GET") {
    try {
      const { resources } = await container.items
        .query("SELECT * FROM c ORDER BY c.timestamp DESC OFFSET 0 LIMIT 50")
        .fetchAll();

      context.res = {
        status: 200,
        headers,
        body: JSON.stringify(resources)
      };
    } catch (err) {
      context.res = {
        status: 500,
        headers,
        body: JSON.stringify({ error: "Erro ao ler scans: " + err.message })
      };
    }
    return;
  }

  // ─── POST /api/function → disparar scan e guardar no CosmosDB ────────────
  if (req.method === "POST") {
    const { url } = req.body || {};

    if (!url) {
      context.res = {
        status: 400,
        headers,
        body: JSON.stringify({ error: "Campo 'url' é obrigatório." })
      };
      return;
    }

    try {
      // 1. Chamar o scanner
      const scanResponse = await fetch(process.env.SCANNER_URL + "/scans", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url })
      });

      if (!scanResponse.ok) {
        throw new Error(`Scanner devolveu status ${scanResponse.status}`);
      }

      const scanResult = await scanResponse.json();

      // 2. Construir documento para o CosmosDB
      const scanId = `scan_${Date.now()}`;
      const document = {
        id: scanId,
        scan_id: scanId,
        url,
        timestamp: new Date().toISOString(),
        status: "completed",
        riskScore: scanResult.riskScore ?? 0,
        vulnerabilities: scanResult.vulnerabilities ?? [],
        vulnerabilityCount: Array.isArray(scanResult.vulnerabilities)
          ? scanResult.vulnerabilities.length
          : (scanResult.vulnerabilityCount ?? 0)
      };

      // 3. Guardar no CosmosDB
      await container.items.create(document);

      context.res = {
        status: 200,
        headers,
        body: JSON.stringify(document)
      };
    } catch (err) {
      context.res = {
        status: 500,
        headers,
        body: JSON.stringify({ error: "Erro no scan: " + err.message })
      };
    }
    return;
  }

  // Método não suportado
  context.res = {
    status: 405,
    headers,
    body: JSON.stringify({ error: "Método não suportado." })
  };
};